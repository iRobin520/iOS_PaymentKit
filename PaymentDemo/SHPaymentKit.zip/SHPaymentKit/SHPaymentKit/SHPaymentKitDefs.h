//
//  SHPaymentKitDefs.h
//  SHPaymentKit
//
//  Created by RobinShen on 15/8/21.
//  Copyright (c) 2015年 sh. All rights reserved.
//

//Union Pay
static NSString *kSHUnionPayAppBundleId = @"com.sh.wcc";
static NSString *kSHUnionPayAppScheme = @"unionpay.wconcept";
static NSString *kApplePayMerchantId = @"merchant.com.wcc";

//Alipay
static NSString *kSHAlipayAppBundleId = @"com.alipay.iphoneclient";
static NSString *kSHAlipayPartner = @"2088021168585767";
static NSString *kSHAlipaySeller = @"lookoptical@163.com";
static NSString *kSHAlipayAppId = @"2015081800221416";
static NSString *kSHAlipayService = @"mobile.securitypay.pay";
static NSString *kSHAlipayInputCharset = @"utf-8";
static NSString *kSHAlipayPaymentType = @"1";
static NSString *kSHAlipayItBPay = @"30m";
static NSString *kShAlipayShowUrl = @"www.wconcept.cn";
static NSString *kSHAlipayAppScheme = @"wconcept";
static NSString *kSHAlipayPrivateKey = @"MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPFcUBm8HH8/VTVuhP7X4f/YM0kl23Fq/iBW95EdWndK5TGjumON+V5tQTPyGKaZX6wIZKw0RNlfSOvIGAVd6n9VrXtIAOoc3yJW1I8WjQrwEm9gMOnJWf3jjpv9/CGh4/iiwMM1VzMTnYF9InwAr89HTjh9SVVl1BLiE9QrPkp9AgMBAAECgYBIelATakmkbIBJ60ZEwM885M+Bx7x98oMdcwAks4vXBsaMgX4XJysbD/PkhW6hmK0CHAMfMxL5s4NSSmPsOKeRv/6mwffR7e95al8Vc8AYLu8GhMe2g9GdI3dLcdvtVm/5ebqg6LR4e+7wQBRLSBBUm2JlgtEA0LDAKBX4e5ucgQJBAPjt3FdMtTItBcF+pJOx4WMnXOj03Iae+HKygKY0REBpXnU1q1i+NIyS0V1KgLB6nRNvB7X7TutEdcVOhdBdwiMCQQD4N2p7wNoY4eLNoNhd8ebA22Q2HOS7watBI+0E2VuvWsJtzVkr00FU/nU8gasFwRpSysg6u3RZcqww4TAn1PrfAkEArVbVDGV594qqa2cIq2A+lpEefYmk1ol0cEokk5fpvwCgqfXJb25joU/LQq9SlZGMN7AlKm/pMKLnb5GSVNo1CQJBAKnkfDzSJjVrvupR0maS4QdV4wRqyGB+0bHXXi64e1nNvFCdghBOG2SKekH82ssofdT3OQ+CKMPkilk2eNh6nW8CQGd/+8x7BhVnKj0lNuyt5AwdhtjZSrRpku2VGEShAQ8GugpAZgz6WuRs0VOPJ8bWGQhrxrU6knai+N6JlW/ioTw=";
